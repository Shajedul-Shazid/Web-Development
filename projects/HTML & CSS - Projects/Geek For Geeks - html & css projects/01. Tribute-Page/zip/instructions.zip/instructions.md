Approach:

1. In the <body> element, we will give the title of the page using h1 tag 

2. after that we will add an image of him in the img tag with some caption. 

3. We will create another div tag and write all the contents (using p tags). 

4. We have also given ID for each tag so that we can beautify the design using respective-ID in the CSS file.

5. In the CSS section, we have basically maintained a central design and used box-shadow to create box effect around the main content.